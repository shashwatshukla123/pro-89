export const firebaseConfig = {
    apiKey: "AIzaSyCITRsTEK0MrRTpEGMEvS5d0J9C3tqMQDI",
    authDomain: "storytelling-app-28e1c.firebaseapp.com",
    databaseURL: "https://storytelling-app-28e1c-default-rtdb.firebaseio.com",
    projectId: "storytelling-app-28e1c",
    storageBucket: "storytelling-app-28e1c.appspot.com",
    messagingSenderId: "42343628982",
    appId: "1:42343628982:web:a48a6c3023e155632fa617"
  };
